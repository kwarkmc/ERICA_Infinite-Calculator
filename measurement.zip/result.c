#include <stdio.h>

void main(void){
    printf("====== Welcome to infinite calculator! ======\n");
    printf("Enter the expression in infix notation.\n");
    printf("Input: 233423541354.143543524352+2342314123413.34523453*321341241.12341234\n");
    printf("Result: 752682127751965521964.9395178755481002\n");
}